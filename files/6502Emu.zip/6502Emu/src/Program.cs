﻿using System.Diagnostics;
using SFML.Window;
using SFML.Graphics;
using SFML.System;
using System.Text;

namespace Experiment1
{
    internal class Program
    {
        static CPU6502 cpu;
        static Random random;
        static Stopwatch tickerTimer;

        static ulong clock;
        static int cyclesPerFrame;

        static Texture tex;
        static Image img;
        static Sprite spr;
        static RenderWindow wnd;
        static Color[] colors;

        const string menu =
            """
            Для корректной работы переключите язык ввода на английский!
            Для игр используйте регулировку скорости кнопками + - на цифр. блоке клавиатуры
            Демонстрации:
                1 - Треугольник Серпиского
                2 - Треугольник Серпиского 2
                3 - Слоистый шум
                4 - Узорная линия
                5 - Цветные полосы
                6 - Конфетти
                7 - Демо 1
                8 - Демо 2
                9 - Pong
                0 - Цветовое безумие
            Игры:
                A - Змейка (Управление на W A S D)
                B - Уклонение от препятствий
            Клавиши
                Цифр. + -  --> Скорость
                Ctrl + С   --> Перезапуск
            """;

        static Program()
        {
            img         = new(32, 32, Color.Green);
            tex         = new(img);
            spr         = new(tex);
            spr.Scale   = new(8f, 8f);
            wnd         = new(new VideoMode(256, 256), "Screen", Styles.Close, new ContextSettings());
            wnd.Closed += Wnd_Closed;

            cpu         = new();
            random      = new((int)DateTime.Now.Ticks);
            tickerTimer = new();

            cyclesPerFrame = 301;

            colors = new Color[16]
            {
                new Color(0x000000ff),
                new Color(0xffffffff),
                new Color(0x880000ff),
                new Color(0xaaffeeff),
                new Color(0xcc44ccff),
                new Color(0x00cc55ff),
                new Color(0x0000aaff),
                new Color(0xeeee77ff),
                new Color(0xdd8855ff),
                new Color(0x664400ff),
                new Color(0xff7777ff),
                new Color(0x333333ff),
                new Color(0x777777ff),
                new Color(0xaaff66ff),
                new Color(0x0088ffff),
                new Color(0xbbbbbbff)
            };
        }

        static void Main()
        {
            Console.TreatControlCAsInput = true;
            Console.CursorVisible = false;
            Console.Title = "Registers";
        lReset:
            for (int i = 0; i < 0x10000; i++) cpu.Mem[i] = 0;
            cpu.Regs.PC = 0x600;
            cpu.Regs.A = 0;
            cpu.Regs.X = 0;
            cpu.Regs.Y = 0;
            cpu.Regs.S = 0xFF;
            cpu.Regs.P = State.Reserved | State.B;

            Console.Clear();
            Console.WriteLine("Hello, World!");
            Console.Write(menu);

            while (!Console.KeyAvailable)
            {
                wnd.DispatchEvents();
                Thread.Sleep(1);
            }

            var pkey = Console.ReadKey().Key;
            string[] code = Programs.programs[pkey].Split(' ');

            for (int i = 0; i < code.Length; i++) cpu.Mem[(ushort)(0x600 + i)] = byte.Parse(code[i], System.Globalization.NumberStyles.HexNumber);

            Console.Clear();

            while (true)
            {
                tickerTimer.Restart();

                if (Console.KeyAvailable)
                {
                    var key = Console.ReadKey();
                    if (key.Modifiers.HasFlag(ConsoleModifiers.Control) && key.Key == ConsoleKey.C)
                    {
                        Render();
                        Debug();
                        goto lReset;
                    }
                    else if (key.Key == ConsoleKey.Add) cyclesPerFrame += 30;
                    else if (key.Key == ConsoleKey.Subtract && cyclesPerFrame > 1) cyclesPerFrame -= 30;
                    else cpu.Mem[0xff] = (byte)key.KeyChar;
                }

                for (int i = 0; i < cyclesPerFrame; i++)
                {
                    clock++;
                    cpu.Mem[0xfe] = (byte)random.Next();
                    if (cpu.Opcodes[cpu.Mem[cpu.Regs.PC]].Invoke() == -1)
                    {
                        Render();
                        Debug();
                        goto lReset;
                    }
                }

                tickerTimer.Stop();
                Render();
                Thread.Sleep(Math.Clamp((int)((1000 / 60) - tickerTimer.ElapsedMilliseconds), 0, int.MaxValue));
            }
        }

        static void Wnd_Closed(object? sender, EventArgs e) => Environment.Exit(0);

        static string ToBin(byte b)
        {
            var str = new StringBuilder("00000000", 8);
            for (int i = 0; i < 8; i++, b >>= 1) str[7 - i] = (b & 1) == 1 ? '1' : '0';
            return str.ToString();
        }

        static void Render()
        {
            for (uint i = 0; i < 32; i++) for (uint j = 0; j < 32; j++)
            {
                //Да, скорость этого метода стремится к нулю, но для 1024 пикселей сойдет...
                img.SetPixel(j, i, colors[cpu.Mem[0x200 + ((int)i * 32) + (int)j] & 0b1111]);
            }

            tex.Update(img);
            wnd.Clear();
            wnd.Draw(spr);
            wnd.Display();
            wnd.DispatchEvents();

            if (true)
            {
                Console.SetCursorPosition(0, 0);
                Console.Write(
                    $"""
                    Clock: {clock} (CPF: {cyclesPerFrame})                         
                    A:  {cpu.Regs.A:X2} ({ToBin(cpu.Regs.A)})                                      
                    X:  {cpu.Regs.X:X2} ({ToBin(cpu.Regs.X)}), Y: {cpu.Regs.Y:X2} ({ToBin(cpu.Regs.Y)})                                        
                    PC: {cpu.Regs.PC:X4}                                               
                    S:  {cpu.Regs.S:X2} ({ToBin(cpu.Regs.S)})                                               
                    P:  
                    """);

                for (int i = 7; i >= 0; i--)
                {
                    Console.ForegroundColor = cpu.Regs.P.HasFlag((State)(1 << i)) ? ConsoleColor.Green : ConsoleColor.Red;
                    Console.Write($"{(i == 5 ? "-" : (State)(1 << i))} ");
                }
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine();
            }   
        }
        static void Debug()
        {
            Console.WriteLine("\nBreak.");
            Console.ReadKey();
            for (int p = 0; p < 16; p++)
            {
                Console.WriteLine($"\rСтраница: {p}. {p switch { 1 => "(Стек)", 2 => "(Экран 1)", 3 => "(Экран 2)", 4 => "(Экран 3)", 5 => "(Экран 4)", 6 => "(Код)", _ => "" }}");
                for (int i = 0; i < 16; i++)
                {
                    for (int j = 0; j < 16; j++) Console.Write($"{cpu.Mem[i * 16 + j + (p * 256)]:X2} ");
                    Console.WriteLine();
                }
                Console.WriteLine();
            }
            Console.WriteLine("Нажмите любую клавишу для перезапуска.");
            Console.ReadKey();
        }
    }
}