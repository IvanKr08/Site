﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Experiment1
{
    //Public API
    internal partial class CPU6502
    {
        public static ushort BP { get => 0x100; }
        public MemoryManager Mem { get; }
        public Registers Regs { get; }
        public Func<int>[] Opcodes { get; }

        public CPU6502()
        {
            Opcodes = new Func<int>[256]
            {
              //0    1    2    3--  4    5    6    7--  8    9    A    B--  C    D    E    F--
                BRK, ORA, UNK, UNK, UNK, ORA, ASL, UNK, STI, ORA, ASL, UNK, UNK, ORA, ASL, UNK, //0
                BRI, ORA, UNK, UNK, UNK, ORA, ASL, UNK, FLI, ORA, UNK, UNK, UNK, ORA, ASL, UNK, //1
                JSR, AND, UNK, UNK, BIT, AND, ROL, UNK, STI, AND, ROL, UNK, BIT, AND, ROL, UNK, //2
                BRI, AND, UNK, UNK, UNK, AND, ROL, UNK, FLI, AND, UNK, UNK, UNK, AND, ROL, UNK, //3
                RTI, EOR, UNK, UNK, UNK, EOR, LSR, UNK, STI, EOR, LSR, UNK, JMP, EOR, LSR, UNK, //4
                BRI, EOR, UNK, UNK, UNK, EOR, LSR, UNK, FLI, EOR, UNK, UNK, UNK, EOR, LSR, UNK, //5
                RTS, ADC, UNK, UNK, UNK, ADC, ROR, UNK, STI, ADC, ROR, UNK, JMP, ADC, ROR, UNK, //6
                BRI, ADC, UNK, UNK, UNK, ADC, ROR, UNK, FLI, ADC, UNK, UNK, UNK, ADC, ROR, UNK, //7
                UNK, STA, UNK, UNK, STY, STA, STX, UNK, REI, UNK, REI, UNK, STY, STA, STX, UNK, //8
                BRI, STA, UNK, UNK, STY, STA, STX, UNK, REI, STA, STI, UNK, UNK, STA, UNK, UNK, //9
                LDY, LDA, LDX, UNK, LDY, LDA, LDX, UNK, REI, LDA, REI, UNK, LDY, LDA, LDX, UNK, //A
                BRI, LDA, UNK, UNK, LDY, LDA, LDX, UNK, FLI, LDA, STI, UNK, LDY, LDA, LDX, UNK, //B
                CPY, CMP, UNK, UNK, CPY, CMP, MID, UNK, REI, CMP, REI, UNK, CPY, CMP, MID, UNK, //C
                BRI, CMP, UNK, UNK, UNK, CMP, MID, UNK, FLI, CMP, UNK, UNK, UNK, CMP, MID, UNK, //D
                CPX, SBC, UNK, UNK, CPX, SBC, MID, UNK, REI, SBC, NOP, UNK, CPX, SBC, MID, UNK, //E
                BRI, SBC, UNK, UNK, UNK, SBC, MID, UNK, FLI, SBC, UNK, UNK, UNK, SBC, MID, UNK, //F
            };
            Mem = new MemoryManager();
            Regs = new Registers();
        }
    }
}
