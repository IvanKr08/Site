﻿using System.Runtime.CompilerServices;
using System.Xml.Schema;
using System.Xml.XPath;

namespace Experiment1
{
    //Opcodes
    internal partial class CPU6502
    {
        #region UNK INV - Service
        public int UNK()
        {
            Console.WriteLine($"Unknown Opcode (${Mem[Regs.PC]:X2}) On {Regs.PC:X4} !");
            return -1;
        }
        public int INV() => return -1;
        #endregion


        #region SBC ADC ASL LSR ROL ROR - Math
        public int ADC()
        {
            byte val = 0;
            switch (Mem[Regs.PC])
            {
                case 0x69: //Imm
                    val = GetImmediate();
                    break;
                case 0x65: //ZPage
                    val = GetZeroPageD();
                    break;
                case 0x75: //ZPage,X
                    val = GetZeroPageX();
                    break;
                case 0x6D: //Abs
                    val = GetAbsoluteD();
                    break;
                case 0x7D: //Abs,X
                    val = GetAbsoluteX();
                    break;
                case 0x79: //Abs,Y
                    val = GetAbsoluteY();
                    break;
                case 0x61: //Ind,X
                    val = GetIndirectX();
                    break;
                case 0x71: //Ind,Y
                    val = GetIndirectY();
                    break;
                default:
                    INV();
                    break;
            }

            uint result = (uint)(Regs.A + val + Regs.P.HasFlagInt(State.C));
            Regs.P.SetFlag(State.V, !((Regs.A ^ val) & 0x80).ToBool() && ((Regs.A ^ result) & 0x80).ToBool());
            Regs.P.SetFlag(State.C, result > 0xFF);
            Regs.P.SetNZ((int)result);
            Regs.A = (byte)result;
            return 2;
        }
        public int SBC()
        {
            byte val = 0;
            switch (Mem[Regs.PC])
            {
                case 0xE9: //Imm
                    val = GetImmediate();
                    break;
                case 0xE5: //ZPage
                    val = GetZeroPageD();
                    break;
                case 0xF5: //ZPage,X
                    val = GetZeroPageX();
                    break;
                case 0xED: //Abs
                    val = GetAbsoluteD();
                    break;
                case 0xFD: //Abs,X
                    val = GetAbsoluteX();
                    break;
                case 0xF9: //Abs,Y
                    val = GetAbsoluteY();
                    break;
                case 0xE1: //Ind,X
                    val = GetIndirectX();
                    break;
                case 0xF1: //Ind,Y
                    val = GetIndirectY();
                    break;
                default:
                    INV();
                    break;
            }

            uint result = (uint)(Regs.A - val - (Regs.P.HasFlag(State.C) ? 0 : 1));
            Regs.P.SetFlag(State.V, ((Regs.A ^ result) & 0x80).ToBool() && ((Regs.A ^ val) & 0x80).ToBool());
            Regs.P.SetFlag(State.C, result < 0x100);
            Regs.P.SetNZ((byte)result);
            Regs.A = (byte)result;
            return 2;
        }
        
        public int ASL()
        {
            ushort addr = 0;
            switch (Mem[Regs.PC])
            {
                case 0x0A: //Acc
                    Regs.P.SetFlag(State.C, Regs.A & 0x80);
                    Regs.A <<= 1;
                    Regs.P.SetNZ(Regs.A);
                    Regs.PC++;
                    return 2;
                case 0x06: //ZPage
                    addr = GetZeroPageDPtr();
                    break;
                case 0x16: //ZPage,X
                    addr = GetZeroPageXPtr();
                    break;
                case 0x0E: //Abs
                    addr = GetAbsoluteDPtr();
                    break;
                case 0x1E: //Abs,X
                    addr = GetAbsoluteXPtr();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetFlag(State.C, Mem[addr] & 0x80);
            Mem[addr] <<= 1;
            Regs.P.SetNZ(Mem[addr]);
            return 2;
        }
        public int LSR()
        {
            ushort addr = 0;
            switch (Mem[Regs.PC])
            {
                case 0x4A: //Acc
                    Regs.P.SetFlag(State.C, Regs.A & 0x01);
                    Regs.A >>= 1;
                    Regs.P.SetNZ(Regs.A);
                    Regs.PC++;
                    return 2;
                case 0x46: //ZPage
                    addr = GetZeroPageDPtr();
                    break;
                case 0x56: //ZPage,X
                    addr = GetZeroPageXPtr();
                    break;
                case 0x4E: //Abs
                    addr = GetAbsoluteDPtr();
                    break;
                case 0x5E: //Abs,X
                    addr = GetAbsoluteXPtr();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetFlag(State.C, Mem[addr] & 0x01);
            Mem[addr] >>= 0x01;
            Regs.P.SetNZ(Mem[addr]);
            return 2;
        }

        public int ROL()
        {
            ushort addr = 0x00;
            int bit7;
            switch (Mem[Regs.PC])
            {
                case 0x2A: //Acc
                    bit7 = Regs.A & 0x80;
                    Regs.A <<= 0x01;
                    Regs.A.SetBit(0x00, Regs.P.HasFlag(State.C));
                    Regs.P.SetFlag(State.C, bit7);
                    Regs.P.SetNZ(Regs.A);
                    Regs.PC++;
                    return 2;
                case 0x26: //ZPage
                    addr = GetZeroPageDPtr();
                    break;
                case 0x36: //ZPage,X
                    addr = GetZeroPageXPtr();
                    break;
                case 0x2E: //Abs
                    addr = GetAbsoluteDPtr();
                    break;
                case 0x3E: //Abs,X
                    addr = GetAbsoluteXPtr();
                    break;
                default:
                    INV();
                    break;
            }

            bit7 = Mem[addr] & 0x80;
            Mem[addr] <<= 0x01;
            Mem[addr].SetBit(0x00, Regs.P.HasFlag(State.C));
            Regs.P.SetFlag(State.C, bit7);
            Regs.P.SetNZ(Mem[addr]);
            return 2;
        }
        public int ROR()
        {
            ushort addr = 0;
            int bit0;
            switch (Mem[Regs.PC])
            {
                case 0x6A: //Acc
                    bit0 = Regs.A & 0x01;
                    Regs.A >>= 1;
                    Regs.A.SetBit(7, Regs.P.HasFlag(State.C));
                    Regs.P.SetFlag(State.C, bit0);
                    Regs.P.SetNZ(Regs.A);
                    Regs.PC++;
                    return 2;
                case 0x66: //ZPage
                    addr = GetZeroPageDPtr();
                    break;
                case 0x76: //ZPage,X
                    addr = GetZeroPageXPtr();
                    break;
                case 0x6E: //Abs
                    addr = GetAbsoluteDPtr();
                    break;
                case 0x7E: //Abs,X
                    addr = GetAbsoluteXPtr();
                    break;
                default:
                    INV();
                    break;
            }

            bit0 = Mem[addr] & 0x01;
            Mem[addr] >>= 1;
            Mem[addr].SetBit(7, Regs.P.HasFlag(State.C));
            Regs.P.SetFlag(State.C, bit0);
            Regs.P.SetNZ(Mem[addr]);
            return 2;
        }
        #endregion


        #region LDA LDX LDY - Load Register
        public int LDA()
        {
            switch (Mem[Regs.PC])
            {
                case 0xA9: //Imm
                    Regs.A = GetImmediate();
                    break;
                case 0xA5: //ZPage
                    Regs.A = GetZeroPageD();
                    break;
                case 0xB5: //ZPage,X
                    Regs.A = GetZeroPageX();
                    break;
                case 0xAD: //Abs
                    Regs.A = GetAbsoluteD();
                    break;
                case 0xBD: //Abs,X
                    Regs.A = GetAbsoluteX();
                    break;
                case 0xB9: //Abs,Y
                    Regs.A = GetAbsoluteY();
                    break;
                case 0xA1: //Ind,X
                    Regs.A = GetIndirectX();
                    break;
                case 0xB1: //Ind,Y
                    Regs.A = GetIndirectY();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetNZ(Regs.A);
            return 2;
        }
        public int LDX()
        {
            switch (Mem[Regs.PC])
            {
                case 0xA2: //Imm
                    Regs.X = GetImmediate();
                    break;
                case 0xA6: //ZPage
                    Regs.X = GetZeroPageD();
                    break;
                case 0xB6: //ZPage,Y
                    Regs.X = GetZeroPageY();
                    break;
                case 0xAE: // Abs
                    Regs.X = GetAbsoluteD();
                    break;
                case 0xBE: //Abs,Y
                    Regs.X = GetAbsoluteY();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetNZ(Regs.X);
            return 2;
        }
        public int LDY()
        {
            switch (Mem[Regs.PC])
            {
                case 0xA0: //Imm
                    Regs.Y = GetImmediate();
                    break;
                case 0xA4: //ZPage
                    Regs.Y = GetZeroPageD();
                    break;
                case 0xB4: //ZPage,X
                    Regs.Y = GetZeroPageX();
                    break;
                case 0xAC: //Abs
                    Regs.Y = GetAbsoluteD();
                    break;
                case 0xBC: //Abs,X
                    Regs.Y = GetAbsoluteX();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetNZ(Regs.Y);
            return 2;
        }
        #endregion


        #region STA STX STY - Store Register
        public int STA()
        {
            switch (Mem[Regs.PC])
            {
                case 0x85: //ZPage
                    GetZeroPageD() = Regs.A;
                    break;
                case 0x95: //ZPage,X
                    GetZeroPageX() = Regs.A;
                    break;
                case 0x8D: //Abs
                    GetAbsoluteD() = Regs.A;
                    break;
                case 0x9D: //Abs,X
                    GetAbsoluteX() = Regs.A;
                    break;
                case 0x99: //Abs,Y
                    GetAbsoluteY() = Regs.A;
                    break;
                case 0x81: //Ind,X
                    GetIndirectX() = Regs.A;
                    break;
                case 0x91: //Ind,Y
                    GetIndirectY() = Regs.A;
                    break;
                default:
                    INV();
                    break;
            }

            return 2;
        }
        public int STX()
        {
            switch (Mem[Regs.PC])
            {
                case 0x86: //ZPage
                    GetZeroPageD() = Regs.X;
                    break;
                case 0x96: //ZPage,Y
                    GetZeroPageY() = Regs.X;
                    break;
                case 0x8E: //Abs
                    GetAbsoluteD() = Regs.X;
                    break;
                default:
                    INV();
                    break;
            }

            return 2;
        }
        public int STY()
        {
            switch (Mem[Regs.PC])
            {
                case 0x84: //ZPage
                    GetZeroPageD() = Regs.Y;
                    break;
                case 0x94: //ZPage,X
                    GetZeroPageX() = Regs.Y;
                    break;
                case 0x8C: //Abs
                    GetAbsoluteD() = Regs.Y;
                    break;
                default:
                    INV();
                    break;
            }

            return 2;
        }
        #endregion


        #region AND ORA EOR - Bitwise AND/OR/XOR
        public int AND()
        {
            switch (Mem[Regs.PC])
            {
                case 0x29:
                    Regs.A &= GetImmediate();
                    break;
                case 0x25:
                    Regs.A &= GetZeroPageD();
                    break;
                case 0x35:
                    Regs.A &= GetZeroPageX();
                    break;
                case 0x2D:
                    Regs.A &= GetAbsoluteD();
                    break;
                case 0x3D:
                    Regs.A &= GetAbsoluteX();
                    break;
                case 0x39:
                    Regs.A &= GetAbsoluteY();
                    break;
                case 0x21:
                    Regs.A &= GetIndirectX();
                    break;
                case 0x31:
                    Regs.A &= GetIndirectY();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetNZ(Regs.A);
            return 2;
        }
        public int ORA()
        {
            switch (Mem[Regs.PC])
            {
                case 0x09:
                    Regs.A |= GetImmediate();
                    break;
                case 0x05:
                    Regs.A |= GetZeroPageD();
                    break;
                case 0x15:
                    Regs.A |= GetZeroPageX();
                    break;
                case 0x0D:
                    Regs.A |= GetAbsoluteD();
                    break;
                case 0x1D:
                    Regs.A |= GetAbsoluteX();
                    break;
                case 0x19:
                    Regs.A |= GetAbsoluteY();
                    break;
                case 0x01:
                    Regs.A |= GetIndirectX();
                    break;
                case 0x11:
                    Regs.A |= GetIndirectY();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetNZ(Regs.A);
            return 2;
        }
        public int EOR()
        {
            switch (Mem[Regs.PC])
            {
                case 0x49:
                    Regs.A ^= GetImmediate();
                    break;
                case 0x45:
                    Regs.A ^= GetZeroPageD();
                    break;
                case 0x55:
                    Regs.A ^= GetZeroPageX();
                    break;
                case 0x4D:
                    Regs.A ^= GetAbsoluteD();
                    break;
                case 0x5D:
                    Regs.A ^= GetAbsoluteX();
                    break;
                case 0x59:
                    Regs.A ^= GetAbsoluteY();
                    break;
                case 0x41:
                    Regs.A ^= GetIndirectX();
                    break;
                case 0x51:
                    Regs.A ^= GetIndirectY();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetNZ(Regs.A);
            return 2;
        }
        #endregion


        #region BPL BMI BVC BVS BCC BCS BNE BQE - Conditional Branch
        public int BRI() //Branch Instructions
        {
            ushort newAddress = GetRelativeDPtr();

            switch (Mem[Regs.PC - 2])
            {
                case 0x10: //BPL
                    if (!Regs.P.HasFlag(State.N)) Regs.PC = newAddress;
                    break;
                case 0x30: //BMI
                    if (Regs.P.HasFlag(State.N)) Regs.PC = newAddress;
                    break;
                case 0x50: //BVC
                    if (!Regs.P.HasFlag(State.V)) Regs.PC = newAddress;
                    break;
                case 0x70: //BVS
                    if (Regs.P.HasFlag(State.V)) Regs.PC = newAddress;
                    break;
                case 0x90: //BCC
                    if (!Regs.P.HasFlag(State.C)) Regs.PC = newAddress;
                    break;
                case 0xB0: //BCS
                    if (Regs.P.HasFlag(State.C)) Regs.PC = newAddress;
                    break;
                case 0xD0: //BNE
                    if (!Regs.P.HasFlag(State.Z)) Regs.PC = newAddress;
                    break;
                case 0xF0: //BEQ
                    if (Regs.P.HasFlag(State.Z)) Regs.PC = newAddress;
                    break;
                default:
                    INV();
                    break;
            }

            return 2;
        }
        #endregion


        #region TAX TXA DEX INX TAY TYA DEY INY - Fast Register Instructions
        public int REI() //Register Instructions
        {
            switch (Mem[Regs.PC])
            {
                case 0xAA: //TAX
                    Regs.X = Regs.A;
                    Regs.P.SetNZ(Regs.X);
                    break;
                case 0x8A: //TXA
                    Regs.A = Regs.X;
                    Regs.P.SetNZ(Regs.A);
                    break;
                case 0xCA: //DEX
                    Regs.X--;
                    Regs.P.SetNZ(Regs.X);
                    break;
                case 0xE8: //INX
                    Regs.X++;
                    Regs.P.SetNZ(Regs.X);
                    break;
                case 0xA8: //TAY
                    Regs.Y = Regs.A;
                    Regs.P.SetNZ(Regs.Y);
                    break;
                case 0x98: //TYA
                    Regs.A = Regs.Y;
                    Regs.P.SetNZ(Regs.A);
                    break;
                case 0x88: //DEY
                    Regs.Y--;
                    Regs.P.SetNZ(Regs.Y);
                    break;
                case 0xC8: //INY
                    Regs.Y++;
                    Regs.P.SetNZ(Regs.Y);
                    break;
                default:
                    INV();
                    return Regs.A;
            }

            Regs.PC++;
            return 2;
        }
        #endregion


        #region JMP JSR RTS RTI - Unconditional Jump
        public int JMP()
        {
            switch (Mem[Regs.PC])
            {
                case 0x4C: //Abs
                    Regs.PC = GetAbsoluteDPtr(true);
                    return 3;
                case 0x6C: //Ind
                    Regs.PC = GetIndirectDPtr(true);
                    return 5;
                default:
                    INV();
                    return 3;
            }
        }
        public int JSR()
        {
            ushort subAddr = GetAbsoluteDPtr();
            Regs.PC--;
            PushToStack((byte)(Regs.PC >> 8));
            PushToStack((byte)(Regs.PC & 0xFF));
            Regs.PC = subAddr;
            return 6;
        }
        public int RTS()
        {
            byte low = PullFromStack();
            byte high = PullFromStack();
            Regs.PC = (ushort)(((high << 8) | low) + 1);
            return 6;
        }
        public int RTI()
        {
            throw new NotImplementedException();
        }
        #endregion


        #region CMP CPX CPY - Compare Register With Memory
        public int CMP()
        {
            byte val = 0;
            switch (Mem[Regs.PC])
            {
                case 0xC9:
                    val = GetImmediate();
                    break;
                case 0xC5:
                    val = GetZeroPageD();
                    break;
                case 0xD5:
                    val = GetZeroPageX();
                    break;
                case 0xCD:
                    val = GetAbsoluteD();
                    break;
                case 0xDD:
                    val = GetAbsoluteX();
                    break;
                case 0xD9:
                    val = GetAbsoluteY();
                    break;
                case 0xC1:
                    val = GetIndirectX();
                    break;
                case 0xD1:
                    val = GetIndirectY();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetFlag(State.C, Regs.A >= val);
            Regs.P.SetFlag(State.Z, Regs.A == val);
            Regs.P.SetFlag(State.N, (int)State.N & (Regs.A - val));
            return 2;
        }
        public int CPX()
        {
            byte val = 0;
            switch (Mem[Regs.PC])
            {
                case 0xE0:
                    val = GetImmediate();
                    break;
                case 0xE4:
                    val = GetZeroPageD();
                    break;
                case 0xEC:
                    val = GetAbsoluteD();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetFlag(State.C, Regs.X >= val);
            Regs.P.SetFlag(State.N, (int)State.N & (Regs.X - val));
            Regs.P.SetFlag(State.Z, Regs.X == val);
            return 2;
        }
        public int CPY()
        {
            byte val = 0;
            switch (Mem[Regs.PC])
            {
                case 0xC0:
                    val = GetImmediate();
                    break;
                case 0xC4:
                    val = GetZeroPageD();
                    break;
                case 0xCC:
                    val = GetAbsoluteD();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetFlag(State.C, Regs.Y >= val);
            Regs.P.SetFlag(State.N, (int)State.N & (Regs.Y - val));
            Regs.P.SetFlag(State.Z, Regs.Y == val);
            return 2;
        }
        #endregion


        #region TXS TSX PHA PLA PHP PLP - Stack Instructions
        public int STI()
        {
            Regs.PC++;
            switch (Mem[Regs.PC - 1])
            {
                case 0x9A: //TXS
                    Regs.S = Regs.X;
                    return 2;
                case 0xBA: //TSX
                    Regs.X = Regs.S;
                    Regs.P.SetNZ(Regs.X);
                    return 2;
                case 0x48: //PHA
                    PushToStack(Regs.A);
                    return 3;
                case 0x68: //PLA
                    Regs.A = PullFromStack();
                    Regs.P.SetNZ(Regs.A);
                    return 4;
                case 0x08: //PHP
                    PushToStack((byte)Regs.P);
                    return 3;
                case 0x28: //PLP
                    Regs.P = (State)PullFromStack();
                    return 4;
                default:
                    INV();
                    return 2;
            }
        }
        #endregion


        #region INC DEC | CLC SEC CLI SEI CLV CLD SED | NOP | BIT | BRK - Other
        public int MID() //Memory Increment-Decrement
        {
            ushort ptr = 0;
            switch (Mem[Regs.PC])
            {
                case 0xE6:
                    ptr = GetZeroPageDPtr();
                    Mem[ptr]++;
                    break;
                case 0xF6:
                    ptr = GetZeroPageXPtr();
                    Mem[ptr]++;
                    break;
                case 0xEE:
                    ptr = GetAbsoluteDPtr();
                    Mem[ptr]++;
                    break;
                case 0xFE:
                    ptr = GetAbsoluteXPtr();
                    Mem[ptr]++;
                    break;
                case 0xC6:
                    ptr = GetZeroPageDPtr();
                    Mem[ptr]--;
                    break;
                case 0xD6:
                    ptr = GetZeroPageXPtr();
                    Mem[ptr]--;
                    break;
                case 0xCE:
                    ptr = GetAbsoluteDPtr();
                    Mem[ptr]--;
                    break;
                case 0xDE:
                    ptr = GetAbsoluteXPtr();
                    Mem[ptr]--;
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetNZ(Mem[ptr]);
            return 2;
        }
        public int FLI() //Flag Instructions
        {
            switch (Mem[Regs.PC])
            {
                case 0x18: //CLC
                    Regs.P.SetFlag(State.C, 0);
                    break;
                case 0x38: //SEC
                    Regs.P.SetFlag(State.C, 1);
                    break;
                case 0x58: //CLI
                    Regs.P.SetFlag(State.I, 0);
                    break;
                case 0x78: //SEI
                    Regs.P.SetFlag(State.I, 1);
                    break;
                case 0xB8: //CLV
                    Regs.P.SetFlag(State.V, 0);
                    break;
                case 0xD8: //CLD
                    Regs.P.SetFlag(State.D, 0);
                    break;
                case 0xF8: //SED
                    throw new NotImplementedException();
                    Regs.P.SetFlag(State.D, 1);
                    break;
                default:
                    INV();
                    break;
            }

            Regs.PC++;
            return 2;
        }
        public int NOP()
        {
            Regs.PC++;
            return 2;
        }
        public int BIT()
        {
            byte val = 0;
            switch (Mem[Regs.PC])
            {
                case 0x24:
                    val = GetZeroPageD();
                    break;
                case 0x2C:
                    val = GetAbsoluteD();
                    break;
                default:
                    INV();
                    break;
            }

            Regs.P.SetFlag(State.V, (int)State.V & val);
            Regs.P.SetFlag(State.N, (int)State.N & val);
            Regs.P.SetFlag(State.Z, (Regs.A & val) == 0);
            return 2;
        }
        public int BRK()
        {
            Console.WriteLine("NMI");
            return -1;
        }
        #endregion
    }
}