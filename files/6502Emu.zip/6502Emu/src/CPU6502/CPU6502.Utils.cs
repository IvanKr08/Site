﻿using System.Runtime.CompilerServices;

namespace Experiment1
{
    //Misc
    internal partial class CPU6502
    {
        #region Getters - Get Memory By Addressing Mode
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetImmediate(bool silent = false)
        {
            if (silent) return ref Mem[Regs.PC + 1];
            Regs.PC += 2;
            return ref Mem[Regs.PC - 1];
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetAbsoluteD(bool silent = false) => ref Mem[GetAbsoluteDPtr(silent)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetAbsoluteX(bool silent = false) => ref Mem[GetAbsoluteXPtr(silent)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetAbsoluteY(bool silent = false) => ref Mem[GetAbsoluteYPtr(silent)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetZeroPageD(bool silent = false) => ref Mem[GetZeroPageDPtr(silent)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetZeroPageX(bool silent = false) => ref Mem[GetZeroPageXPtr(silent)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetZeroPageY(bool silent = false) => ref Mem[GetZeroPageYPtr(silent)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetIndirectX(bool silent = false) => ref Mem[GetIndirectXPtr(silent)];

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ref byte GetIndirectY(bool silent = false) => ref Mem[GetIndirectYPtr(silent)];

        //===

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetRelativeDPtr(bool silent = false)
        {
            sbyte shift = (sbyte)Mem[Regs.PC + 1];
            ushort addr = (ushort)(Regs.PC + 2 + shift);
            if (!silent) Regs.PC += 2;
            return addr;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetZeroPageDPtr(bool silent = false)
        {
            byte addr = Mem[Regs.PC + 1];
            if (!silent) Regs.PC += 2;
            return addr;
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetZeroPageXPtr(bool silent = false) => (byte)(GetZeroPageDPtr(silent) + Regs.X);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetZeroPageYPtr(bool silent = false) => (byte)(GetZeroPageDPtr(silent) + Regs.Y);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetAbsoluteDPtr(bool silent = false)
        {
            byte low = Mem[Regs.PC + 1];
            byte high = Mem[Regs.PC + 2];
            if (!silent) Regs.PC += 3;
            return (ushort)((high << 8) | low);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetAbsoluteXPtr(bool silent = false) => (ushort)(GetAbsoluteDPtr(silent) + Regs.X);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetAbsoluteYPtr(bool silent = false) => (ushort)(GetAbsoluteDPtr(silent) + Regs.Y);

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetIndirectDPtr(bool silent = false)
        {
            ushort addr = GetAbsoluteDPtr(silent);
            byte low = Mem[addr];
            if (addr >> 8 != (ushort)(addr + 1) >> 8) addr -= 0x100;
            byte high = Mem[addr + 1];

            return (ushort)((high << 8) | low);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetIndirectXPtr(bool silent = false)
        {
            byte addr = (byte)(Mem[Regs.PC + 1] + Regs.X);
            if (!silent) Regs.PC += 2;
            return (ushort)((Mem[(byte)(addr + 1)] << 8) | Mem[addr]);
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public ushort GetIndirectYPtr(bool silent = false)
        {
            byte off = Mem[Regs.PC + 1];
            ushort addr = (ushort)(
                Mem[off] | (Mem[(off + 1) & 0xFF] << 8)
                );
            if (!silent) Regs.PC += 2;
            return (ushort)(addr + Regs.Y);
        }
        #endregion


        #region Stack Utils
        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public byte PullFromStack()
        {
            Regs.S++;
            return Mem[BP + Regs.S];
        }

        [MethodImpl(MethodImplOptions.AggressiveInlining)]
        public void PushToStack(byte val)
        {
            Mem[BP + Regs.S] = val;
            Regs.S--;
        }
        #endregion
    }
}
