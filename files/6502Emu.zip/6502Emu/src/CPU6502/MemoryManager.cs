﻿using System;

namespace Experiment1
{
    internal class MemoryManager
    {
        private readonly byte[] memory = new byte[65536];
        public ref byte this[int i] { get => ref memory[(ushort)i]; }
        public ref byte this[ushort i] { get => ref memory[i]; }
    }
}